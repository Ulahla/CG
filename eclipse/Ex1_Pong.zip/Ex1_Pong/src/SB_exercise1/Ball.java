package SB_exercise1;

import org.lwjgl.opengl.GL11;

public class Ball {

	public Ball(int width, int height, float timeDiff) {
		// TODO Auto-generated constructor stub
	}

	public void draw(int x, int y){
		GL11.glPointSize(10);
		
		GL11.glBegin(GL11.GL_POINTS);
		GL11.glVertex2d(x,y);
		GL11.glEnd();
	}
}
