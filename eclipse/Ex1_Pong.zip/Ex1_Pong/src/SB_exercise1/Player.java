package SB_exercise1;

import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class Player{

	private String name;
	private int yPlayerPos = KickPong.height/2;
//	private final int xPlayerPos = 80;
	private boolean isRunning;
//	private boolean end;
	private int yPlayerSpeed = 200;
	int keyUp;
	int keyDown;


	public Player(String name, int keyUp, int keyDown){
//		this.name = name;
//		this.yPlayerPos = yPlayerPos;
//		end = false;
		this.keyUp = keyUp;
		this.keyDown = keyDown;
	}

	public void draw(int xPlayerPos){
		GL11.glBegin(GL11.GL_QUADS);
		GL11.glVertex2d(xPlayerPos, yPlayerPos-30);
		GL11.glVertex2d(xPlayerPos, yPlayerPos+30);
		GL11.glVertex2d(xPlayerPos+5, yPlayerPos+30);
		GL11.glVertex2d(xPlayerPos+5, yPlayerPos-30);
//		move();
		move(keyUp, keyDown);
		GL11.glEnd();
	}

	public void move(int keyUp, int keyDown){
		if(Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) KickPong.end = true;
//		if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) isRunning = true;
		if(Keyboard.isKeyDown(keyUp)) yPlayerPos 	 += yPlayerSpeed * KickPong.timeDiff;
		if(Keyboard.isKeyDown(keyDown)) yPlayerPos -= yPlayerSpeed * KickPong.timeDiff;
	}


}
