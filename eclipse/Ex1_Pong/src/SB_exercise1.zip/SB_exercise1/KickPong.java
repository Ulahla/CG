package SB_exercise1;

import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

public class KickPong {
	public static int width  = 800;
	public static int height = 600;
	public static long lastTime = 0;
	public static float timeDiff = 0;
	public static boolean end = false;
	public Player player1;
	public Player player2;
	public Ball ball;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KickPong app = new KickPong();
		app.run();
	}

	public void init(){
		try {
			Display.setDisplayMode(new DisplayMode(width, height));
			Display.create();
			
			//initialize Players and Ball
			player1 = new Player("player2", Keyboard.KEY_W, Keyboard.KEY_S);
			player2 = new Player("player1", Keyboard.KEY_UP, Keyboard.KEY_DOWN);
			ball = new Ball(width, height, timeDiff);
			
		} catch (LWJGLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//set OpenGL ortho
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();
		GL11.glOrtho(0, width, 0, height, 1, -1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		
		// Set Background Color
		GL11.glClearColor(0.3f, 0.3f, 0.3f, 1f);
		
		lastTime = Sys.getTime();
		}
	
	private void run(){
		
		init();
		
		while(!end){
			end = update();
			draw();
		}
	}
	
	private void draw(){
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		

			GL11.glColor3d(0.f, 1.f, 1.f);
			player1.draw(80);
			player2.draw(width-80);

			GL11.glColor3d(0.2f, 0.2f, 0.2f);
			drawLine(width/2-2, 0, width/2+2, height);
			
			GL11.glColor3d(Math.random(), Math.random(), Math.random());
			ball.draw(width/2, height/2);
	}
	
	private void drawLine(int xs, int ys, int xe, int ye) {
		GL11.glBegin(GL11.GL_QUADS);
		GL11.glVertex2d(xs, ys);
		GL11.glVertex2d(xs, ye);
		GL11.glVertex2d(xe, ye);
		GL11.glVertex2d(xe, ys);
		GL11.glEnd();
	}

	private boolean update(){

		long aktTime = Sys.getTime();
		timeDiff = ((float)(aktTime-lastTime))/Sys.getTimerResolution();
		lastTime = aktTime;
//		System.out.println(timeDiff);
		
		Display.update();
		Display.sync(20);
		return Display.isCloseRequested();
	}


}
